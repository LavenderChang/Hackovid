# Project name: Hackovid
# Course: Python game programming
# Group: 3-1
# Game type: role-playing game
# Engineer: Watson Chao
# Institute: department of Engineering Science - NCKU
# File: font.py

import pygame
from config import *
from sprites import *


class Font:
    def __init__(self):
        # 設定字型
        pygame.init()
        self.font = pygame.font.Font("texts/NotoSerifCJKtc-Regular.otf", 20)
        pygame.font.init()

    def get_text(self, text_file):
        # 讀取文字檔
        file = open(text_file, "r", encoding="utf-8")
        text = (file.read())
        return text

    def get_image(self, text):
        # 取得圖片
        image = self.font.render(text, True, (0, 0, 0), (255, 255, 255))
        return image




# 取得文字
HINT = Font().get_text('texts/plots/hint.txt')

# 設定情節-第一節
PLOT_ONE_1 = Font().get_text('texts/plots/plot_one_1.txt')
PLOT_ONE_2 = Font().get_text('texts/plots/plot_one_2.txt')
PLOT_ONE_3 = Font().get_text('texts/plots/plot_one_3.txt')
PLOT_ONE_4 = Font().get_text('texts/plots/plot_one_4.txt')
PLOT_ONE_5 = Font().get_text('texts/plots/plot_one_5.txt')
PLOT_ONE_6 = Font().get_text('texts/plots/plot_one_6.txt')
PLOT_ONE_7 = Font().get_text('texts/plots/plot_one_7.txt')
PLOT_ONE_8 = Font().get_text('texts/plots/plot_one_8.txt')
PLOT_ONE_9 = Font().get_text('texts/plots/plot_one_9.txt')
PLOT_ONE_10 = Font().get_text('texts/plots/plot_one_10.txt')
PLOT_ONE_11 = Font().get_text('texts/plots/plot_one_11.txt')

# 設定情節-第二節
PLOT_TWO_1 = Font().get_text('texts/plots/plot_two_1.txt')
PLOT_TWO_2 = Font().get_text('texts/plots/plot_two_2.txt')
PLOT_TWO_3 = Font().get_text('texts/plots/plot_two_3.txt')
PLOT_TWO_4 = Font().get_text('texts/plots/plot_two_4.txt')
PLOT_TWO_5 = Font().get_text('texts/plots/plot_two_5.txt')

# 設定情節-第三節
PLOT_THREE_1 = Font().get_text('texts/plots/plot_three_1.txt')
PLOT_THREE_2 = Font().get_text('texts/plots/plot_three_2.txt')
PLOT_THREE_3 = Font().get_text('texts/plots/plot_three_3.txt')
PLOT_THREE_4 = Font().get_text('texts/plots/plot_three_4.txt')
PLOT_THREE_5 = Font().get_text('texts/plots/plot_three_5.txt')
PLOT_THREE_6 = Font().get_text('texts/plots/plot_three_6.txt')

# 設定情節-第四節
PLOT_FOUR_1 = Font().get_text('texts/plots/plot_four_1.txt')
PLOT_FOUR_2 = Font().get_text('texts/plots/plot_four_2.txt')

# 設定情節-第五節
PLOT_FIVE_1 = Font().get_text('texts/plots/plot_five_1.txt')
PLOT_FIVE_2 = Font().get_text('texts/plots/plot_five_2.txt')
PLOT_FIVE_3 = Font().get_text('texts/plots/plot_five_3.txt')
PLOT_FIVE_4 = Font().get_text('texts/plots/plot_five_4.txt')
PLOT_FIVE_5 = Font().get_text('texts/plots/plot_five_5.txt')

PLOT_SIX_1 = Font().get_text('texts/plots/plot_six_1.txt')
PLOT_SIX_2 = Font().get_text('texts/plots/plot_six_2.txt')
PLOT_SIX_3 = Font().get_text('texts/plots/plot_six_3.txt')
PLOT_SIX_4 = Font().get_text('texts/plots/plot_six_4.txt')
PLOT_SIX_5 = Font().get_text('texts/plots/plot_six_5.txt')
PLOT_SIX_6 = Font().get_text('texts/plots/plot_six_6.txt')
PLOT_SIX_7 = Font().get_text('texts/plots/plot_six_7.txt')
PLOT_SIX_8 = Font().get_text('texts/plots/plot_six_8.txt')
PLOT_SIX_9 = Font().get_text('texts/plots/plot_six_9.txt')
PLOT_SIX_10 = Font().get_text('texts/plots/plot_six_10.txt')
PLOT_SIX_11 = Font().get_text('texts/plots/plot_six_11.txt')
PLOT_SIX_12 = Font().get_text('texts/plots/plot_six_12.txt')
PLOT_SIX_13 = Font().get_text('texts/plots/plot_six_13.txt')
PLOT_SIX_14 = Font().get_text('texts/plots/plot_six_14.txt')
PLOT_SIX_15 = Font().get_text('texts/plots/plot_six_15.txt')
PLOT_SIX_16 = Font().get_text('texts/plots/plot_six_16.txt')
PLOT_SIX_17 = Font().get_text('texts/plots/plot_six_17.txt')
PLOT_SIX_18 = Font().get_text('texts/plots/plot_six_18.txt')

PLOT_SEVEN_1 = Font().get_text('texts/plots/plot_seven_1.txt')
PLOT_SEVEN_2 = Font().get_text('texts/plots/plot_seven_2.txt')
PLOT_SEVEN_3 = Font().get_text('texts/plots/plot_seven_3.txt')
PLOT_SEVEN_4 = Font().get_text('texts/plots/plot_seven_4.txt')
PLOT_SEVEN_5 = Font().get_text('texts/plots/plot_seven_5.txt')
PLOT_SEVEN_6 = Font().get_text('texts/plots/plot_seven_6.txt')
PLOT_SEVEN_7 = Font().get_text('texts/plots/plot_seven_7.txt')

PLOT_EIGHT_GAMEOVER_1 = Font().get_text('texts/plots/plot_eight_gameover_1.txt')
PLOT_EIGHT_GAMEOVER_2 = Font().get_text('texts/plots/plot_eight_gameover_2.txt')
PLOT_EIGHT_GAMEOVER_3 = Font().get_text('texts/plots/plot_eight_gameover_3.txt')

PLOT_EIGHT_1 = Font().get_text('texts/plots/plot_eight_1.txt')
PLOT_EIGHT_2 = Font().get_text('texts/plots/plot_eight_2.txt')
PLOT_EIGHT_3 = Font().get_text('texts/plots/plot_eight_3.txt')
PLOT_EIGHT_4 = Font().get_text('texts/plots/plot_eight_4.txt')
PLOT_EIGHT_5 = Font().get_text('texts/plots/plot_eight_5.txt')
PLOT_EIGHT_6 = Font().get_text('texts/plots/plot_eight_6.txt')
PLOT_EIGHT_7 = Font().get_text('texts/plots/plot_eight_7.txt')
PLOT_EIGHT_8 = Font().get_text('texts/plots/plot_eight_8.txt')
PLOT_EIGHT_9 = Font().get_text('texts/plots/plot_eight_9.txt')

# 設定電腦的對話和選項
COMPUTER_title = Font().get_text('texts/computer/computer_title')
COMPUTER_first_choice = Font().get_text('texts/computer/computer_first_choice')
COMPUTER_second_choice = Font().get_text('texts/computer/computer_second_choice')
COMPUTER_third_choice = Font().get_text('texts/computer/computer_third_choice')
COMPUTER_fourth_choice = Font().get_text('texts/computer/computer_fourth_choice')

COMPUTER_title_1 = Font().get_text('texts/computer/computer_title_1')
COMPUTER_first_choice_1 = Font().get_text('texts/computer/computer_first_choice_1')
COMPUTER_second_choice_1 = Font().get_text('texts/computer/computer_second_choice_1')
COMPUTER_third_choice_1 = Font().get_text('texts/computer/computer_third_choice_1')
COMPUTER_fourth_choice_1 = Font().get_text('texts/computer/computer_fourth_choice_1')

COMPUTER_title_2 = Font().get_text('texts/computer/computer_title_2')
COMPUTER_first_choice_2 = Font().get_text('texts/computer/computer_first_choice_2')
COMPUTER_second_choice_2 = Font().get_text('texts/computer/computer_second_choice_2')
COMPUTER_third_choice_2 = Font().get_text('texts/computer/computer_third_choice_2')
COMPUTER_fourth_choice_2 = Font().get_text('texts/computer/computer_fourth_choice_2')

COMPUTER_title_3 = Font().get_text('texts/computer/computer_title_3')
COMPUTER_first_choice_3 = Font().get_text('texts/computer/computer_first_choice_3')
COMPUTER_second_choice_3 = Font().get_text('texts/computer/computer_second_choice_3')
COMPUTER_third_choice_3 = Font().get_text('texts/computer/computer_third_choice_3')
COMPUTER_fourth_choice_3 = Font().get_text('texts/computer/computer_fourth_choice_3')

COMPUTER_title_3_1 = Font().get_text('texts/computer/computer_title_3_1')
COMPUTER_first_choice_3_1 = Font().get_text('texts/computer/computer_first_choice_3_1')
COMPUTER_second_choice_3_1 = Font().get_text('texts/computer/computer_second_choice_3_1')
COMPUTER_third_choice_3_1 = Font().get_text('texts/computer/computer_third_choice_3_1')
COMPUTER_fourth_choice_3_1 = Font().get_text('texts/computer/computer_fourth_choice_3_1')

COMPUTER_title_3_2 = Font().get_text('texts/computer/computer_title_3_2')
COMPUTER_first_choice_3_2 = Font().get_text('texts/computer/computer_first_choice_3_2')
COMPUTER_second_choice_3_2 = Font().get_text('texts/computer/computer_second_choice_3_2')
COMPUTER_third_choice_3_2 = Font().get_text('texts/computer/computer_third_choice_3_2')
COMPUTER_fourth_choice_3_2 = Font().get_text('texts/computer/computer_fourth_choice_3_2')

COMPUTER_title_4 = Font().get_text('texts/computer/computer_title_4')
COMPUTER_first_choice_4 = Font().get_text('texts/computer/computer_first_choice_4')
COMPUTER_second_choice_4 = Font().get_text('texts/computer/computer_second_choice_4')
COMPUTER_third_choice_4 = Font().get_text('texts/computer/computer_third_choice_4')
COMPUTER_fourth_choice_4 = Font().get_text('texts/computer/computer_fourth_choice_4')

# 設定媽媽的對話和選項
MOM_title = Font().get_text('texts/mom/mom_title')
MOM_first_choice = Font().get_text('texts/mom/mom_first_choice')
MOM_second_choice = Font().get_text('texts/mom/mom_second_choice')
MOM_third_choice = Font().get_text('texts/mom/mom_third_choice')
MOM_fourth_choice = Font().get_text('texts/mom/mom_fourth_choice')

MOM_title_1 = Font().get_text('texts/mom/mom_title_1')
MOM_first_choice_1 = Font().get_text('texts/mom/mom_first_choice_1')
MOM_second_choice_1 = Font().get_text('texts/mom/mom_second_choice_1')
MOM_third_choice_1 = Font().get_text('texts/mom/mom_third_choice_1')
MOM_fourth_choice_1 = Font().get_text('texts/mom/mom_fourth_choice_1')

MOM_title_2 = Font().get_text('texts/mom/mom_title_2')
MOM_first_choice_2 = Font().get_text('texts/mom/mom_first_choice_2')
MOM_second_choice_2 = Font().get_text('texts/mom/mom_second_choice_2')
MOM_third_choice_2 = Font().get_text('texts/mom/mom_third_choice_2')
MOM_fourth_choice_2 = Font().get_text('texts/mom/mom_fourth_choice_2')

MOM2_third_choice = Font().get_text('texts/mom/mom2_third_choice')
MOM2_title_3 = Font().get_text('texts/mom/mom_title_3')
MOM2_first_choice_3 = Font().get_text('texts/mom/mom_first_choice_3')
MOM2_second_choice_3 = Font().get_text('texts/mom/mom_second_choice_3')
MOM2_third_choice_3 = Font().get_text('texts/mom/mom_third_choice_3')
MOM2_fourth_choice_3 = Font().get_text('texts/mom/mom_fourth_choice_3')

TAKE = Font().get_text('texts/item/take.txt')
LEAVE = Font().get_text('texts/item/leave.txt')

CLUE_PAPER = Font().get_text('texts/item/clue_paper.txt')