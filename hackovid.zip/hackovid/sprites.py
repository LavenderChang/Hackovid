# Project name: Hackovid
# Course: Python game programming
# Group: 3-1
# Game type: role-playing game
# Engineer: Watson Chao
# Institute: department of Engineering Science - NCKU
# File: sprites.py

import pygame
import math
from config import *
from font import *


class SpritesSheet:    # 定義 SpritesSheet 功能
    def __init__(self, file):
        self.sheet = pygame.image.load(file).convert()

    def get_sprite(self, x, y, width, height):
        sprite = pygame.Surface((width, height))
        sprite.blit(self.sheet, (0, 0), (x, y, width, height))
        sprite.set_colorkey((0, 0, 0))
        return sprite


class Player:   # 定義角色相關內容

    def __init__(self, game, x, y):
        # 遊戲開始後，定義角色所處的層
        self.game = game
        self._layer = PLAYER_LAYER
        # 定義角色大小及位置
        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = 2*TILE_SIZE
        self.height = 2*TILE_SIZE
        # 定義角色初始面向
        self.facing = 'down'
        self.animation_loop = 1
        # 定義角色初始移動變量
        self.x_change = 0
        self.y_change = 0
        # 定義角色初始移動變量
        self.image = self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height)
        # 獲取角色位置
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def movement(self):
        # 設定上下左右的移動操控
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            self.y_change -= PLAYER_SPEED
            self.facing = 'up'
        if keys[pygame.K_a]:
            self.x_change -= PLAYER_SPEED
            self.facing = 'left'
        if keys[pygame.K_s]:
            self.y_change += PLAYER_SPEED
            self.facing = 'down'
        if keys[pygame.K_d]:
            self.x_change += PLAYER_SPEED
            self.facing = 'right'

    def collide_blocks(self, direction):    # 定義角色碰撞方式
        # 如果撞到被定義為 block 的物件
        for block in self.game.blocks.blocks_list:
            hit = self.rect.colliderect(block.rect)
            # 如果橫向移動時撞到物品，角色停下
            if direction == "x":
                if hit:
                    if self.x_change > 0:
                        self.rect.right = block.rect.left
                    if self.x_change < 0:
                        self.rect.left = block.rect.right
            # 如果綜向移動時撞到物品，角色停下
            if direction == "y":
                if hit:
                    if self.y_change > 0:
                        self.rect.bottom = block.rect.top
                    if self.y_change < 0:
                        self.rect.top = block.rect.bottom
        # 如果撞到被定義為 npc 的物件
        for npc in self.game.NPCs.NPCs_list:
            hit = self.rect.colliderect(npc.rect)
            self.detect_gameover_2_2(npc)
            # 如果橫向移動時撞到物品，角色停下
            if direction == "x":
                if hit:
                    if self.x_change > 0:
                        self.rect.right = npc.rect.left
                    if self.x_change < 0:
                        self.rect.left = npc.rect.right
            # 如果綜向移動時撞到物品，角色停下
            if direction == "y":
                if hit:
                    if self.y_change > 0:
                        self.rect.bottom = npc.rect.top
                    if self.y_change < 0:
                        self.rect.top = npc.rect.bottom

            for item in self.game.items.items_list:
                hit = self.rect.colliderect(item.rect)
                # 如果橫向移動時撞到物品，角色停下
                if direction == "x":
                    if hit:
                        if self.x_change > 0:
                            self.rect.right = item.rect.left
                        if self.x_change < 0:
                            self.rect.left = item.rect.right
                # 如果綜向移動時撞到物品，角色停下
                if direction == "y":
                    if hit:
                        if self.y_change > 0:
                            self.rect.bottom = item.rect.top
                        if self.y_change < 0:
                            self.rect.top = item.rect.bottom

    def animate(self):  # 定義角色移動時動畫
        # 定義角色 向下 移動時圖片動畫
        down_animation = [self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height),
                          self.game.character_spritesheet.get_sprite(2*TILE_SIZE, 0, self.width, self.height),
                          self.game.character_spritesheet.get_sprite(4*TILE_SIZE, 0, self.width, self.height),
                          self.game.character_spritesheet.get_sprite(6*TILE_SIZE, 0, self.width, self.height)]
        # 定義角色 向上 移動時圖片動畫
        up_animation = [self.game.character_spritesheet.get_sprite(0, 2*TILE_SIZE, self.width, self.height),
                        self.game.character_spritesheet.get_sprite(2*TILE_SIZE, 2*TILE_SIZE, self.width, self.height),
                        self.game.character_spritesheet.get_sprite(4*TILE_SIZE, 2*TILE_SIZE, self.width, self.height),
                        self.game.character_spritesheet.get_sprite(6*TILE_SIZE, 2*TILE_SIZE, self.width, self.height)]
        # 定義角色 向左 移動時圖片動畫
        left_animation = [self.game.character_spritesheet.get_sprite(0, 4*TILE_SIZE, self.width, self.height),
                          self.game.character_spritesheet.get_sprite(2*TILE_SIZE, 4*TILE_SIZE, self.width, self.height),
                          self.game.character_spritesheet.get_sprite(4*TILE_SIZE, 4*TILE_SIZE, self.width, self.height),
                          self.game.character_spritesheet.get_sprite(6*TILE_SIZE, 4*TILE_SIZE, self.width, self.height)]
        # 定義角色 向右 移動時圖片動畫
        right_animation = [self.game.character_spritesheet.get_sprite(0, 6*TILE_SIZE, self.width, self.height),
                           self.game.character_spritesheet.get_sprite(2*TILE_SIZE, 6*TILE_SIZE, self.width, self.height),
                           self.game.character_spritesheet.get_sprite(4*TILE_SIZE, 6*TILE_SIZE, self.width, self.height),
                           self.game.character_spritesheet.get_sprite(6*TILE_SIZE, 6*TILE_SIZE, self.width, self.height)]
        # 如果角色 向下 移動，讓角色圖片變為 面朝下 的圖片組
        if self.facing == 'down':
            if self.y_change == 0:
                self.image = self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = down_animation[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 4:
                    self.game.walk_sound.play()
                    self.animation_loop = 1
        # 如果角色 向上 移動，讓角色圖片變為 面朝上 的圖片組
        if self.facing == 'up':
            if self.y_change == 0:
                self.image = self.game.character_spritesheet.get_sprite(0, 2*TILE_SIZE, self.width, self.height)
            else:
                self.image = up_animation[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 4:
                    self.game.walk_sound.play()
                    self.animation_loop = 1
        # 如果角色 向左 移動，讓角色圖片變為 面朝左 的圖片組
        if self.facing == 'left':
            if self.x_change == 0:
                self.image = self.game.character_spritesheet.get_sprite(0, 4*TILE_SIZE, self.width, self.height)
            else:
                self.image = left_animation[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 4:
                    self.game.walk_sound.play()
                    self.animation_loop = 1
        # 如果角色 向右 移動，讓角色圖片變為 面朝右 的圖片組
        if self.facing == 'right':
            if self.x_change == 0:
                self.image = self.game.character_spritesheet.get_sprite(0, 6*TILE_SIZE, self.width, self.height)
            else:
                self.image = right_animation[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 4:
                    self.game.walk_sound.play()
                    self.animation_loop = 1

    def detect_gameover_2_2(self, npc):
        if self.game.scene_2_1_complete:
            if npc.name == 'Boss' or npc.name == 'Government official':
                hit = self.rect.colliderect(npc.rect)
                if hit:
                    self.game.killed_sound.play()
                    self.game.plots.scene_2_2_gameover = True


class PlayerGroup:  # 設角色 List 儲存角色圖片
    def __init__(self, game):
        self.players_list = []
        self.items_list =[]
        self.game = game
        self.protection = 0

    def generate_player(self, x, y):    # 將角色加入角色 List
        self.players_list.append(Player(self.game, x, y))

    def detect_scene_2_1(self):
        for item in self.items_list:
            if item.name == 'clue paper':
                self.game.scene_2_1_complete = True


    def update(self):   # 更新角色資訊
        self.detect_scene_2_1()
        for player in self.players_list:
            player.movement()   # 角色的移動
            player.animate()    # 角色的動畫
            # 角色的碰撞
            player.rect.x += player.x_change
            player.collide_blocks("x")
            player.rect.y += player.y_change
            player.collide_blocks("y")
            # 角色移動變量歸零
            player.x_change = 0
            player.y_change = 0

    def draw(self, screen):  # 畫出角色
        for player in self.players_list:
            screen.blit(player.image, player.rect)


class NPC:  # 設置 NPC 相關內容
    def __init__(self, game, x, y):
        # 設置 NPC 所處的層
        self.game = game
        # 設置 NPC 大小
        self.name = None
        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = 2*TILE_SIZE
        self.height = 2*TILE_SIZE
        # 設置 NPC 路徑
        self.path = None
        self.path_pos = 0
        # 設置 NPC 面向
        self.facing = 'down'
        self.animation_loop = 1
        # 設置 NPC 移動
        self.moving = False
        self.x_change = 0
        self.y_change = 0
        self.speed = 8

        self.max_count = TILE_SIZE/self.speed
        self.move_count = 0
        self.move_goal_x = None
        self.move_goal_y = None

        self.image = self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height)
        # 獲取 NPC 位置
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        self.down_animation = []
        self.up_animation = []
        self.left_animation = []
        self.right_animation = []

        self.image_facing_up = None
        self.image_facing_down = None
        self.image_facing_left = None
        self.image_facing_right = None

    def move(self):  # 定義NPC移動
        if self.moving:
            if self.rect.x == self.move_goal_x and self.rect.y == self.move_goal_y:
                self.moving = False
                self.x_change = 0
                self.y_change = 0
            else:
                if self.path[self.path_pos] == 'x+':
                    self.x_change += self.speed
                elif self.path[self.path_pos] == 'x-':
                    self.x_change -= self.speed
                if self.path[self.path_pos] == 'y+':
                    self.y_change += self.speed
                elif self.path[self.path_pos] == 'y-':
                    self.y_change -= self.speed

            self.path_pos += 1

            if self.y_change == 0:
                if self.x_change > 0:
                    self.facing = 'right'
                if self.x_change < 0:
                    self.facing = 'left'
            if self.x_change == 0:
                if self.y_change > 0:
                    self.facing = 'down'
                if self.y_change < 0:
                    self.facing = 'up'


    def animate(self):
        down_animation = self.down_animation

        up_animation = self.up_animation

        left_animation = self.left_animation

        right_animation = self.right_animation

        if self.facing == 'down':
            if self.y_change == 0:
                self.image = self.image_facing_down
            else:
                self.image = down_animation[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 4:
                    self.game.walk_sound.play()
                    self.animation_loop = 1

        if self.facing == 'up':
            if self.y_change == 0:
                self.image = self.image_facing_up
            else:
                self.image = up_animation[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 4:
                    self.game.walk_sound.play()
                    self.animation_loop = 1

        if self.facing == 'left':
            if self.x_change == 0:
                self.image = self.image_facing_left
            else:
                self.image = left_animation[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 4:
                    self.game.walk_sound.play()
                    self.animation_loop = 1

        if self.facing == 'right':
            if self.x_change == 0:
                self.image = self.image_facing_right
            else:
                self.image = right_animation[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 4:
                    self.game.walk_sound.play()
                    self.animation_loop = 1


    @classmethod
    def Mom(cls, game, x, y):
        mom = cls(game, x, y)
        mom.name = 'Mom'
        mom.path = MOM_PATH
        mom.speed = 4
        mom.move_goal_x = 37*TILE_SIZE
        mom.move_goal_y = 26*TILE_SIZE
        mom.facing = 'down'
        mom.width = 2*TILE_SIZE
        mom.height = 2*TILE_SIZE
        mom.image = mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 8*TILE_SIZE, mom.width, mom.height)
        mom.image_facing_down = mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 8*TILE_SIZE, mom.width, mom.height)
        mom.image_facing_up = mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 10*TILE_SIZE, mom.width, mom.height)
        mom.image_facing_left = mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 12*TILE_SIZE, mom.width, mom.height)
        mom.image_facing_right = mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 14*TILE_SIZE, mom.width, mom.height)
        mom.down_animation = [mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 8*TILE_SIZE, mom.width, mom.height),
                          mom.game.character_spritesheet.get_sprite(10*TILE_SIZE, 8*TILE_SIZE, mom.width, mom.height),
                          mom.game.character_spritesheet.get_sprite(12*TILE_SIZE, 8*TILE_SIZE, mom.width, mom.height),
                          mom.game.character_spritesheet.get_sprite(14* TILE_SIZE, 8*TILE_SIZE, mom.width, mom.height)]

        mom.up_animation = [mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 10*TILE_SIZE, mom.width, mom.height),
                        mom.game.character_spritesheet.get_sprite(10*TILE_SIZE, 10*TILE_SIZE, mom.width, mom.height),
                        mom.game.character_spritesheet.get_sprite(12*TILE_SIZE, 10*TILE_SIZE, mom.width, mom.height),
                        mom.game.character_spritesheet.get_sprite(14*TILE_SIZE, 10*TILE_SIZE, mom.width, mom.height)]

        mom.left_animation = [mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 12*TILE_SIZE, mom.width, mom.height),
                          mom.game.character_spritesheet.get_sprite(10*TILE_SIZE, 12*TILE_SIZE, mom.width, mom.height),
                          mom.game.character_spritesheet.get_sprite(12*TILE_SIZE, 12*TILE_SIZE, mom.width, mom.height),
                          mom.game.character_spritesheet.get_sprite(14*TILE_SIZE, 12*TILE_SIZE, mom.width, mom.height)]

        mom.right_animation = [mom.game.character_spritesheet.get_sprite(8*TILE_SIZE, 14*TILE_SIZE, mom.width, mom.height),
                           mom.game.character_spritesheet.get_sprite(10*TILE_SIZE, 14*TILE_SIZE, mom.width, mom.height),
                           mom.game.character_spritesheet.get_sprite(12*TILE_SIZE, 14*TILE_SIZE, mom.width, mom.height),
                           mom.game.character_spritesheet.get_sprite(14*TILE_SIZE, 14*TILE_SIZE, mom.width, mom.height)]
        return mom

    @classmethod
    def Government_official(cls, game, x, y):
        government_official = cls(game, x, y)
        government_official.name = 'Government official'
        government_official.path = GOVERNMENT_OFFICIAL_PATH
        government_official.speed = 8
        government_official.move_goal_x = 11 * TILE_SIZE
        government_official.move_goal_y = 17 * TILE_SIZE
        government_official.facing = 'up'
        government_official.width = 2*TILE_SIZE
        government_official.height = 2*TILE_SIZE
        government_official.image = government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 0*TILE_SIZE, government_official.width, government_official.height)
        government_official.image_facing_down = government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 0*TILE_SIZE, government_official.width, government_official.height)
        government_official.image_facing_up = government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 2*TILE_SIZE, government_official.width, government_official.height)
        government_official.image_facing_left = government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 4*TILE_SIZE, government_official.width, government_official.height)
        government_official.image_facing_right = government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 6*TILE_SIZE, government_official.width, government_official.height)
        government_official.down_animation = [government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 0*TILE_SIZE, government_official.width, government_official.height),
                          government_official.game.character_spritesheet.get_sprite(10*TILE_SIZE, 0*TILE_SIZE, government_official.width, government_official.height),
                          government_official.game.character_spritesheet.get_sprite(12*TILE_SIZE, 0*TILE_SIZE, government_official.width, government_official.height),
                          government_official.game.character_spritesheet.get_sprite(14* TILE_SIZE, 0*TILE_SIZE, government_official.width, government_official.height)]

        government_official.up_animation = [government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 2*TILE_SIZE, government_official.width, government_official.height),
                        government_official.game.character_spritesheet.get_sprite(10*TILE_SIZE, 2*TILE_SIZE, government_official.width, government_official.height),
                        government_official.game.character_spritesheet.get_sprite(12*TILE_SIZE, 2*TILE_SIZE, government_official.width, government_official.height),
                        government_official.game.character_spritesheet.get_sprite(14*TILE_SIZE, 2*TILE_SIZE, government_official.width, government_official.height)]

        government_official.left_animation = [government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 4*TILE_SIZE, government_official.width, government_official.height),
                          government_official.game.character_spritesheet.get_sprite(10*TILE_SIZE, 4*TILE_SIZE, government_official.width, government_official.height),
                          government_official.game.character_spritesheet.get_sprite(12*TILE_SIZE, 4*TILE_SIZE, government_official.width, government_official.height),
                          government_official.game.character_spritesheet.get_sprite(14*TILE_SIZE, 4*TILE_SIZE, government_official.width, government_official.height)]

        government_official.right_animation = [government_official.game.character_spritesheet.get_sprite(8*TILE_SIZE, 6*TILE_SIZE, government_official.width, government_official.height),
                           government_official.game.character_spritesheet.get_sprite(10*TILE_SIZE, 6*TILE_SIZE, government_official.width, government_official.height),
                           government_official.game.character_spritesheet.get_sprite(12*TILE_SIZE, 6*TILE_SIZE, government_official.width, government_official.height),
                           government_official.game.character_spritesheet.get_sprite(14*TILE_SIZE, 6*TILE_SIZE, government_official.width, government_official.height)]
        return government_official

    @classmethod
    def Boss(cls, game, x, y):
        boss = cls(game, x, y)
        boss.name = 'Boss'
        boss.path = BOSS_PATH
        boss.speed = 8
        boss.move_goal_x = 11*TILE_SIZE
        boss.move_goal_y = 17*TILE_SIZE
        boss.facing = 'down'
        boss.width = 2 * TILE_SIZE
        boss.height = 2 * TILE_SIZE
        boss.image = boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 8 * TILE_SIZE, boss.width, boss.height)
        boss.image_facing_down = boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 8 * TILE_SIZE, boss.width,
                                                                          boss.height)
        boss.image_facing_up = boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 10 * TILE_SIZE, boss.width,
                                                                        boss.height)
        boss.image_facing_left = boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 12 * TILE_SIZE, boss.width,
                                                                          boss.height)
        boss.image_facing_right = boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 14 * TILE_SIZE, boss.width,
                                                                           boss.height)
        boss.down_animation = [
            boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 8 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(2 * TILE_SIZE, 8 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(4 * TILE_SIZE, 8 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(6 * TILE_SIZE, 8 * TILE_SIZE, boss.width, boss.height)]

        boss.up_animation = [
            boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 10 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(2 * TILE_SIZE, 10 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(4 * TILE_SIZE, 10 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(6 * TILE_SIZE, 10 * TILE_SIZE, boss.width, boss.height)]

        boss.left_animation = [
            boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 12 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(2 * TILE_SIZE, 12 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(4 * TILE_SIZE, 12 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(6 * TILE_SIZE, 12 * TILE_SIZE, boss.width, boss.height)]

        boss.right_animation = [
            boss.game.character_spritesheet.get_sprite(0 * TILE_SIZE, 14 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(2 * TILE_SIZE, 14 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(4 * TILE_SIZE, 14 * TILE_SIZE, boss.width, boss.height),
            boss.game.character_spritesheet.get_sprite(6 * TILE_SIZE, 14 * TILE_SIZE, boss.width, boss.height)]
        return boss


class NPCGroup:
    def __init__(self, game):
        self.NPCs_list = []
        self.game = game

    def generate_NPC(self, name, x, y):
        new_npc = None
        if name is None:
            return
        if name == 'Mom':
            new_npc = NPC.Mom(self.game, x, y)
        if name == 'Government official':
            new_npc = NPC.Government_official(self.game, x, y)
        if name == 'Boss':
            new_npc = NPC.Boss(self.game, x, y)

        self.NPCs_list.append(new_npc)

    def move_detection(self):
        for npc in self.NPCs_list:
            if self.game.scene_1_3_complete:
                if npc.name == 'Mom':
                    npc.moving = True
            if self.game.plots.plot_7_played:
                if npc.name == 'Boss' or npc.name == 'Government official':
                    npc.moving = True

    def detect_scene_2_2(self):
        if not self.game.scene_2_2_complete:
            for npc1 in self.NPCs_list:
                if npc1.name == 'Boss':
                    for npc2 in  self.NPCs_list:
                        if npc2.name == 'Government official':
                            hit = npc1.rect.colliderect(npc2.rect)
                            if hit:
                                for npc in self.NPCs_list:
                                    npc.moving = False
                                self.game.scene_2_2_complete = True

    def update(self):
        if self.game.scene_2_1_complete:
            self.detect_scene_2_2()
        for npc in self.NPCs_list:
            npc.move()
            npc.animate()
            npc.rect.x += npc.x_change
            npc.rect.y += npc.y_change
            npc.x_change = 0
            npc.y_change = 0

    def draw(self, screen):
        for npc in self.NPCs_list:
            screen.blit(npc.image, npc.rect)


class Ground:   # 定義可路過的地板
    def __init__(self, game, x, y):
        # 遊戲開始設置地板的大小尺寸
        self.game = game
        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = TILE_SIZE
        self.height = TILE_SIZE
        # 讀取地板素材
        self.image = self.game.terrain_spritesheet.get_sprite(0, 3*TILE_SIZE, self.width, self.height)
        # 讀取地板位置
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    @classmethod
    def grass(cls, game, x, y):
        grass = cls(game, x, y)
        grass.width = TILE_SIZE
        grass.height = TILE_SIZE
        grass.image = grass.game.terrain_spritesheet.get_sprite(3*TILE_SIZE, 6*TILE_SIZE, grass.width, grass.height)
        return grass

    @classmethod
    def road(cls, game, x, y):
        road = cls(game, x, y)
        road.width = TILE_SIZE
        road.height = TILE_SIZE
        road.image = road.game.terrain_spritesheet.get_sprite(0, 5*TILE_SIZE, road.width, road.height)
        return road
    @classmethod
    def cement(cls, game, x, y):
        cement = cls(game, x, y)
        cement.width = TILE_SIZE
        cement.height = TILE_SIZE
        cement.image = cement.game.terrain_spritesheet.get_sprite(TILE_SIZE, 3*TILE_SIZE, cement.width, cement.height)
        return cement


class GroundGroup:
    def __init__(self, game):
        self.grounds_list = []  # 取得地板 List
        self.game = game

    def generate_ground(self, name, x, y):
        new_ground = None
        if name is None:
            return
        # 木頭地板
        if name == 'wood':
            new_ground = Ground(self.game, x, y)
        # 草地地板
        if name == 'grass':
            new_ground = Ground.grass(self.game, x, y)
        # 馬路地板
        if name == 'road':
            new_ground = Ground.road(self.game, x, y)
        if name == 'cement':
            new_ground = Ground.cement(self.game, x, y)
        # 將地板加入 List
        self.grounds_list.append(new_ground)

    def update(self):
        pass

    def draw(self, screen):
        for ground in self.grounds_list:
            screen.blit(ground.image, ground.rect)


class Block:
    def __init__(self, game, x, y):
        self.game = game
        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = TILE_SIZE
        self.height = TILE_SIZE

        self.image = pygame.Surface((self.width, self.height))
        self.image.set_colorkey((0, 0, 0))

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    @classmethod
    def wall(cls, game, x, y):
        wall = cls(game, x, y)
        wall.width = TILE_SIZE
        wall.height = TILE_SIZE
        wall.image = wall.game.terrain_spritesheet.get_sprite(0, 4*TILE_SIZE, wall.width, wall.height)
        return wall

    @classmethod
    def grey_wall(cls, game, x, y):
        grey_wall = cls(game, x, y)
        grey_wall.width = TILE_SIZE
        grey_wall.height = TILE_SIZE
        grey_wall.image = grey_wall.game.terrain_spritesheet.get_sprite(5 * TILE_SIZE, 0, grey_wall.width, grey_wall.height)
        return grey_wall

    @classmethod
    def computer(cls, game, x, y):
        computer = cls(game, x, y)
        computer.width = 2 * TILE_SIZE
        computer.height = 2 * TILE_SIZE
        computer.image = computer.game.furniture_spritesheet.get_sprite(0, 0, 64, 64)
        return computer

    @classmethod
    def bed(cls, game, x, y):
        bed = cls(game, x, y)
        bed.width = 3 * TILE_SIZE
        bed.height = 5 * TILE_SIZE
        bed.image = pygame.transform.scale(bed.game.furniture_spritesheet.get_sprite(64, 0, 96, 160), (115, 192))
        return bed

    @classmethod
    def desk(cls, game, x, y):
        desk = cls(game, x, y)
        desk.width = 3 * TILE_SIZE
        desk.height = 2 * TILE_SIZE
        desk.image = desk.game.furniture_spritesheet.get_sprite(350, 0, 96, 64)
        return desk

    @classmethod
    def chair(cls, game, x, y):
        chair = cls(game, x, y)
        chair.width = 2 * TILE_SIZE
        chair.height = 2 * TILE_SIZE
        chair.image = chair.game.furniture_spritesheet.get_sprite(254, 160, 64, 64)
        return chair

    @classmethod
    def low_cabinet(cls, game, x, y):
        low_cabinet = cls(game, x, y)
        low_cabinet.width = 2 * TILE_SIZE
        low_cabinet.height = 2 * TILE_SIZE
        low_cabinet.image = low_cabinet.game.furniture_spritesheet.get_sprite(160, 96, 64, 64)
        return low_cabinet

    @classmethod
    def bookcase(cls, game, x, y):
        bookcase = cls(game, x, y)
        bookcase.width = 3 * TILE_SIZE
        bookcase.height = 4 * TILE_SIZE
        bookcase.image = bookcase.game.furniture_spritesheet.get_sprite(416, 64, 96, 128)
        return bookcase

    @classmethod
    def TV(cls, game, x, y):
        TV = cls(game, x, y)
        TV.width = 2 * TILE_SIZE
        TV.height = 2 * TILE_SIZE
        TV.image = TV.game.furniture_spritesheet.get_sprite(0, 130, 64, 64)
        return TV

    @classmethod
    def room_sofa(cls, game, x, y):
        room_sofa = cls(game, x, y)
        room_sofa.width = 6 * TILE_SIZE
        room_sofa.height = 6 * TILE_SIZE
        room_sofa.image = room_sofa.game.furniture_spritesheet.get_sprite(256, 368, 96, 64)
        return room_sofa

    @classmethod
    def tree(cls, game, x, y):
        tree = cls(game, x, y)
        tree.width = 1 * TILE_SIZE
        tree.height = 2 * TILE_SIZE
        tree.image = tree.game.furniture_spritesheet.get_sprite(160, 160, 32, 64)
        return tree

    @classmethod
    def rysofa(cls, game, x, y):
        rysofa = cls(game, x, y)
        rysofa.width = TILE_SIZE
        rysofa.height = TILE_SIZE
        rysofa.image = rysofa.game.furniture_spritesheet.get_sprite(0, 360, 64, 96)
        return rysofa

    @classmethod
    def lysofa(cls, game, x, y):
        lysofa = cls(game, x, y)
        lysofa.width = TILE_SIZE
        lysofa.height = TILE_SIZE
        lysofa.image = lysofa.game.furniture_spritesheet.get_sprite(189, 360, 64, 96)
        return lysofa

    @classmethod
    def bysofa(cls, game, x, y):
        bysofa = cls(game, x, y)
        bysofa.width = TILE_SIZE
        bysofa.height = TILE_SIZE
        bysofa.image = bysofa.game.furniture_spritesheet.get_sprite(256, 293, 96, 64)
        return bysofa

    @classmethod
    def cactus(cls, game, x, y):
        cactus = cls(game, x, y)
        cactus.width = TILE_SIZE
        cactus.height = TILE_SIZE
        cactus.image = cactus.game.furniture_spritesheet.get_sprite(128, 160, 32, 64)
        return cactus

    @classmethod
    def clock(cls, game, x, y):
        clock = cls(game, x, y)
        clock.width = TILE_SIZE
        clock.height = TILE_SIZE
        clock.image = clock.game.furniture_spritesheet.get_sprite(0, 64, 32, 32)
        return clock

    @classmethod
    def blackboard(cls, game, x, y):
        blackboard = cls(game, x, y)
        blackboard.width = 6 * TILE_SIZE
        blackboard.height = 3 * TILE_SIZE
        blackboard.image = blackboard.game.furniture_spritesheet.get_sprite(224, 64, blackboard.width, blackboard.height)
        return blackboard

    @classmethod
    def student_desk(cls, game, x, y):
        student_desk = cls(game, x, y)
        student_desk.width = 2 * TILE_SIZE
        student_desk.height = 2 *TILE_SIZE
        student_desk.image = student_desk.game.furniture_spritesheet.get_sprite(192, 160, student_desk.width, student_desk.height)
        return student_desk

    @classmethod
    def locker(cls, game, x, y):
        locker = cls(game, x, y)
        locker.width = TILE_SIZE
        locker.height = TILE_SIZE
        locker.image = pygame.transform.scale(locker.game.furniture_spritesheet.get_sprite(128, 192, locker.width, locker.height), (64, 64))
        return locker

    @classmethod
    def window(cls, game, x, y):
        window = cls(game, x, y)
        window.width = 4 * TILE_SIZE
        window.height = 2 * TILE_SIZE
        window.image = window.game.furniture_spritesheet.get_sprite(224, 0, window.width, window.height)
        return window

    @classmethod
    def police(cls, game, x, y):
        police = cls(game, x, y)
        police.width = 10 * TILE_SIZE
        police.height = 10 * TILE_SIZE
        police.image = police.game.street_spritesheet.get_sprite(320, 0, police.width, police.height)
        return police

    @classmethod
    def school(cls, game, x, y):
        school = cls(game, x, y)
        school.width = 10 * TILE_SIZE
        school.height = 10 * TILE_SIZE
        school.image = school.game.street_spritesheet.get_sprite(0, 0, school.width, school.height)
        return school

    @classmethod
    def tree_1(cls, game, x, y):
        tree_1 = cls(game, x, y)
        tree_1.width = 3 * TILE_SIZE
        tree_1.height = 3 * TILE_SIZE
        tree_1.image = tree_1.game.street_spritesheet.get_sprite(0, 640, tree_1.width, tree_1.height)
        return tree_1

    @classmethod
    def tree_2(cls, game, x, y):
        tree_2 = cls(game, x, y)
        tree_2.width = 3 * TILE_SIZE
        tree_2.height = 3 * TILE_SIZE
        tree_2.image = tree_2.game.street_spritesheet.get_sprite(96, 640, tree_2.width, tree_2.height)
        return tree_2

    @classmethod
    def tree_3(cls, game, x, y):
        tree_3 = cls(game, x, y)
        tree_3.width = 3 * TILE_SIZE
        tree_3.height = 3 * TILE_SIZE
        tree_3.image = tree_3.game.street_spritesheet.get_sprite(192, 640, tree_3.width, tree_3.height)
        return tree_3

    @classmethod
    def home(cls, game, x, y):
        home = cls(game, x, y)
        home.width = 7 * TILE_SIZE
        home.height = 7 * TILE_SIZE
        home.image = home.game.street_spritesheet.get_sprite(640, 0, home.width, home.height)
        return home

    @classmethod
    def buildings(cls, game, x, y):
        buildings = cls(game, x, y)
        buildings.width = 18 * TILE_SIZE
        buildings.height = 9 * TILE_SIZE
        buildings.image = buildings.game.street_spritesheet.get_sprite(0, 320, buildings.width,  buildings.height)
        return buildings

    @classmethod
    def black(cls, game, x, y):
        black = cls(game, x, y)
        black.width = TILE_SIZE
        black.height = TILE_SIZE
        black.image = pygame.Surface((TILE_SIZE, TILE_SIZE))
        black.image.fill((0, 0, 0))
        return black


class BlockGroup:
    def __init__(self, game):
        self.blocks_list = []
        self.game = game

    def generate_block(self, name, x, y):
        new_block = None
        if name is None:
            return
        if name == 'block':
            new_block = Block(self.game, x, y)
        if name == 'wall':
            new_block = Block.wall(self.game, x, y)
        if name == 'grey wall':
            new_block = Block.grey_wall(self.game, x, y)
        if name == 'computer':
            new_block = Block.computer(self.game, x, y)
        if name == 'bed':
            new_block = Block.bed(self.game, x, y)
        if name == 'desk':
            new_block = Block.desk(self.game, x, y)
        if name == 'chair':
            new_block = Block.chair(self.game, x, y)
        if name == 'low_cabinet':
            new_block = Block.low_cabinet(self.game, x, y)
        if name == 'bookcase':
            new_block = Block.bookcase(self.game, x, y)
        if name == 'TV':
            new_block = Block.TV(self.game, x, y)
        if name == 'room_sofa':
            new_block = Block.room_sofa(self.game, x, y)
        if name == 'tree':
            new_block = Block.tree(self.game, x, y)
        if name == 'rysofa':
            new_block = Block.rysofa(self.game, x, y)
        if name == 'lysofa':
            new_block = Block.lysofa(self.game, x, y)
        if name == 'bysofa':
            new_block = Block.bysofa(self.game, x, y)
        if name == 'cactus':
            new_block = Block.cactus(self.game, x, y)
        if name == 'clock':
            new_block = Block.clock(self.game, x, y)
        if name == 'blackboard':
            new_block = Block.blackboard(self.game, x, y)
        if name == 'student_desk':
            new_block = Block.student_desk(self.game, x, y)
        if name == 'locker':
            new_block = Block.locker(self.game, x, y)
        if name == 'window':
            new_block = Block.window(self.game, x, y)
        if name == 'black':
            new_block = Block.black(self.game, x, y)
        if name == 'police':
            new_block = Block.police(self.game, x, y)
        if name == 'school':
            new_block = Block.school(self.game, x, y)
        if name == 'tree_1':
            new_block = Block.tree_1(self.game, x, y)
        if name == 'tree_2':
            new_block = Block.tree_2(self.game, x, y)
        if name == 'tree_3':
            new_block = Block.tree_3(self.game, x, y)
        if name == 'home':
            new_block = Block.home(self.game, x, y)
        if name == 'buildings':
            new_block = Block.buildings(self.game, x, y)

        self.blocks_list.append(new_block)

    def update(self):
        pass

    def draw(self, screen):
        for block in self.blocks_list:
            screen.blit(block.image, block.rect)


class Arrow:
    def __init__(self):
        self.x = ARROW_X
        self.y = ARROW_Y
        self.width = ARROW_WIDTH
        self.height = ARROW_HEIGHT

        self.image = pygame.Surface((self.width, self.height))
        self.image.fill((0, 0, 0))

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y


class ArrowGroup:
    def __init__(self, game):
        self.game = game
        self.arrows_list = []

    def generate_arrows(self):
        self.arrows_list.append(Arrow())

    def update(self):
        pass

    def draw(self, screen):
        for arrow in self.arrows_list:
            screen.blit(arrow.image, arrow.rect)


class DialogueBox:
    def __init__(self, game, dialogueSpot):
        self.dialogueSpot = dialogueSpot
        self.text = None

        self.game = game

        self.x = DIALOGUE_BOX_X
        self.y = DIALOGUE_BOX_Y

        self.width = DIALOGUE_BOX_WIDTH
        self.height = DIALOGUE_BOX_HEIGHT

        self.image = self.game.dialogue_frame.get_sprite(800, 200, 800, 200)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y


    def update(self):
        pass

    @classmethod
    def title_box(cls, game, dialogueSpot):

        title_box = cls(game, dialogueSpot)

        title_box.text = dialogueSpot[0].title

        title_box.x = TITLE_BOX_X
        title_box.y = TITLE_BOX_Y
        title_box.width = TITLE_BOX_WIDTH
        title_box.height = TITLE_BOX_HEIGHT

        title_box.image = Font().get_image(title_box.text)

        title_box.rect = title_box.image.get_rect()
        title_box.rect.x = title_box.x
        title_box.rect.y = title_box.y
        return title_box

    @classmethod
    def choice_one_box(cls, game, dialogueSpot):

        choice_one_box = cls(game, dialogueSpot)
        choice_one_box.text = dialogueSpot[0].first_choice

        choice_one_box.x = CHOICE_ONE_BOX_X
        choice_one_box.y = CHOICE_ONE_BOX_Y
        choice_one_box.width = CHOICE_ONE_BOX_WIDTH
        choice_one_box.height = CHOICE_ONE_BOX_HEIGHT

        choice_one_box.image = Font().get_image(choice_one_box.text)


        choice_one_box.rect = choice_one_box.image.get_rect()
        choice_one_box.rect.x = choice_one_box.x
        choice_one_box.rect.y = choice_one_box.y

        return choice_one_box

    @classmethod
    def choice_two_box(cls, game, dialogueSpot):

        choice_two_box = cls(game, dialogueSpot)
        choice_two_box.text = dialogueSpot[0].second_choice


        choice_two_box.x = CHOICE_TWO_BOX_X
        choice_two_box.y = CHOICE_TWO_BOX_Y
        choice_two_box.width = CHOICE_TWO_BOX_WIDTH
        choice_two_box.height = CHOICE_TWO_BOX_HEIGHT

        choice_two_box.image = choice_two_box.image = Font().get_image(choice_two_box.text)

        choice_two_box.rect = choice_two_box.image.get_rect()
        choice_two_box.rect.x = choice_two_box.x
        choice_two_box.rect.y = choice_two_box.y
        return choice_two_box

    @classmethod
    def choice_three_box(cls, game, dialogueSpot):

        choice_three_box = cls(game, dialogueSpot)
        choice_three_box.text = dialogueSpot[0].third_choice

        choice_three_box.x = CHOICE_THREE_BOX_X
        choice_three_box.y = CHOICE_THREE_BOX_Y
        choice_three_box.width = CHOICE_THREE_BOX_WIDTH
        choice_three_box.height = CHOICE_THREE_BOX_HEIGHT

        choice_three_box.image = choice_three_box.image = Font().get_image(choice_three_box.text)

        choice_three_box.rect = choice_three_box.image.get_rect()
        choice_three_box.rect.x = choice_three_box.x
        choice_three_box.rect.y = choice_three_box.y
        return choice_three_box

    @classmethod
    def choice_four_box(cls, game, dialogueSpot):

        choice_four_box = cls(game, dialogueSpot)
        choice_four_box.text = dialogueSpot[0].fourth_choice

        choice_four_box.x = CHOICE_FOUR_BOX_X
        choice_four_box.y = CHOICE_FOUR_BOX_Y
        choice_four_box.width = CHOICE_FOUR_BOX_WIDTH
        choice_four_box.height = CHOICE_FOUR_BOX_HEIGHT

        choice_four_box.image = choice_four_box.image = Font().get_image(choice_four_box.text)

        choice_four_box.rect = choice_four_box.image.get_rect()
        choice_four_box.rect.x = choice_four_box.x
        choice_four_box.rect.y = choice_four_box.y
        return choice_four_box

    @classmethod
    def text_box(cls, game, dialogueSpot):
        text_box = cls(game, dialogueSpot)
        text_box.text = dialogueSpot[0].text

        text_box.x = TEXT_BOX_X
        text_box.y = TEXT_BOX_Y
        text_box.width = TEXT_BOX_WIDTH
        text_box.height = TEXT_BOX_HEIGHT

        text_box.image = Font().get_image(text_box.text)

        text_box.rect = text_box.image.get_rect()
        text_box.rect.x = text_box.x
        text_box.rect.y = text_box.y
        return text_box


class DialogueBoxGroup:
    def __init__(self, game):
        self.game = game
        self.dialogueBoxes_list = []
        self.dialogueSpot = game.dialogueSpots.in_used
        self.generate = False
        self.generated = False
        self.delete = False
        self.counter = 0
        self.first_choice = 0
        self.second_choice = 0
        self.third_choice = 0

        self.news_1 = self.game.news_1.get_sprite(0, 0, 600, 480)
        self.news_2 = self.game.news_2.get_sprite(0, 0, 600, 480)
        self.displaying = False
        self.news_displaying = []

    def generate_box(self, name):
        new_box = None
        if name is None:
            return
        if name == 'box':
            new_box = DialogueBox(self.game, self.dialogueSpot)
        if name == 'title box':
            new_box = DialogueBox.title_box(self.game, self.dialogueSpot)
        if name == 'choice one box':
            new_box = DialogueBox.choice_one_box(self.game, self.dialogueSpot)
        if name == 'choice two box':
            new_box = DialogueBox.choice_two_box(self.game, self.dialogueSpot)
        if name == 'choice three box':
            new_box = DialogueBox.choice_three_box(self.game, self.dialogueSpot)
        if name == 'choice four box':
            new_box = DialogueBox.choice_four_box(self.game, self.dialogueSpot)
        self.dialogueBoxes_list.append(new_box)

    def generate_four_choice(self):
        self.generate_box('box')
        self.generate_box('title box')
        self.generate_box('choice one box')
        self.generate_box('choice two box')
        self.generate_box('choice three box')
        self.generate_box('choice four box')

    def detect_choice(self):
        for arrow in self.game.arrows.arrows_list:
            if arrow.rect.y == ARROW_CHOOSE_ONE_Y:
                return "1"
            if arrow.rect.y == ARROW_CHOOSE_TWO_Y:
                return "2"
            if arrow.rect.y == ARROW_CHOOSE_THREE_Y:
                return "3"
            if arrow.rect.y == ARROW_CHOOSE_FOUR_Y:
                return "4"

    def detect_end(self, choice):
        if choice == "1":
            if self.counter == 0:
                self.first_choice = 1
                return self.dialogueSpot[0].first_choice_end
            if self.counter == 1:
                self.second_choice = 1
                if self.first_choice == 1:
                    return self.dialogueSpot[0].first_choice_1_end
                if self.first_choice == 2:
                    return self.dialogueSpot[0].first_choice_2_end
                if self.first_choice == 3:
                    return self.dialogueSpot[0].first_choice_3_end
                if self.first_choice == 4:
                    return self.dialogueSpot[0].first_choice_4_end
            if self.counter == 2:
                self.second_choice = 1
                if self.first_choice == 1:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].first_choice_1_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].first_choice_1_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].first_choice_1_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].first_choice_1_4_end
                if self.first_choice == 2:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].first_choice_2_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].first_choice_2_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].first_choice_2_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].first_choice_2_4_end
                if self.first_choice == 3:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].first_choice_3_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].first_choice_3_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].first_choice_3_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].first_choice_3_4_end
                if self.first_choice == 4:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].first_choice_4_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].first_choice_4_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].first_choice_4_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].first_choice_4_4_end
        if choice == "2":
            if self.counter == 0:
                self.first_choice = 2
                return self.dialogueSpot[0].second_choice_end
            if self.counter == 1:
                self.second_choice = 2
                if self.first_choice == 1:
                    return self.dialogueSpot[0].second_choice_1_end
                if self.first_choice == 2:
                    return self.dialogueSpot[0].second_choice_2_end
                if self.first_choice == 3:
                    return self.dialogueSpot[0].second_choice_3_end
                if self.first_choice == 4:
                    return self.dialogueSpot[0].second_choice_4_end
            if self.counter == 2:
                if self.first_choice == 1:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].second_choice_1_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].second_choice_1_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].second_choice_1_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].second_choice_1_4_end
                if self.first_choice == 2:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].second_choice_2_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].second_choice_2_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].second_choice_2_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].second_choice_2_4_end
                if self.first_choice == 3:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].second_choice_3_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].second_choice_3_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].second_choice_3_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].second_choice_3_4_end
                if self.first_choice == 4:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].second_choice_4_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].second_choice_4_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].second_choice_4_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].second_choice_4_4_end
        if choice == "3":
            if self.counter == 0:
                self.first_choice = 3
                return self.dialogueSpot[0].third_choice_end
            if self.counter == 1:
                self.second_choice = 3
                if self.first_choice == 1:
                    return self.dialogueSpot[0].third_choice_1_end
                if self.first_choice == 2:
                    return self.dialogueSpot[0].third_choice_2_end
                if self.first_choice == 3:
                    return self.dialogueSpot[0].third_choice_3_end
                if self.first_choice == 4:
                    return self.dialogueSpot[0].third_choice_4_end
            if self.counter == 2:
                if self.first_choice == 1:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].third_choice_1_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].third_choice_1_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].third_choice_1_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].third_choice_1_4_end
                if self.first_choice == 2:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].third_choice_2_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].third_choice_2_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].third_choice_2_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].third_choice_2_4_end
                if self.first_choice == 3:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].third_choice_3_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].third_choice_3_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].third_choice_3_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].third_choice_3_4_end
                if self.first_choice == 4:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].third_choice_4_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].third_choice_4_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].third_choice_4_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].third_choice_4_4_end
        if choice == "4":
            if self.counter == 0:
                self.first_choice = 4
                return self.dialogueSpot[0].fourth_choice_end
            if self.counter == 1:
                self.second_choice = 4
                if self.first_choice == 1:
                    return self.dialogueSpot[0].fourth_choice_1_end
                if self.first_choice == 2:
                    return self.dialogueSpot[0].fourth_choice_2_end
                if self.first_choice == 3:
                    return self.dialogueSpot[0].fourth_choice_3_end
                if self.first_choice == 4:
                    return self.dialogueSpot[0].fourth_choice_4_end
            if self.counter == 2:
                if self.first_choice == 1:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].fourth_choice_1_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].fourth_choice_1_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].fourth_choice_1_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].fourth_choice_1_4_end
                if self.first_choice == 2:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].fourth_choice_2_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].fourth_choice_2_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].fourth_choice_2_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].fourth_choice_2_4_end
                if self.first_choice == 3:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].fourth_choice_3_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].fourth_choice_3_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].fourth_choice_3_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].fourth_choice_3_4_end
                if self.first_choice == 4:
                    if self.second_choice == 1:
                        return self.dialogueSpot[0].fourth_choice_4_1_end
                    if self.second_choice == 2:
                        return self.dialogueSpot[0].fourth_choice_4_2_end
                    if self.second_choice == 3:
                        return self.dialogueSpot[0].fourth_choice_4_3_end
                    if self.second_choice == 4:
                        return self.dialogueSpot[0].fourth_choice_4_4_end

    def detect_scene_1_2(self, choice):
        if self.dialogueSpot[0].title == COMPUTER_title_3_1:
            if choice == "1" or choice == "2":
                return True
            else:
                return False
        else:
            return False

    def detect_scene_1_3(self):
        if self.dialogueSpot[0].title == MOM2_title_3:
            return True
        else:
            return False

    def end_by_mom_run(self):
        self.counter = 0
        self.first_choice = 0
        self.second_choice = 0
        self.third_choice = 0
        self.game.dialogueSpots.in_dialogue = False
        self.generated = False
        self.delete = True
        self.game.scene_1_3_complete = True
        self.game.NPCs.move_detection()

    def get_news(self, choice):
        if choice == "1":
            news = self.news_1
            self.game.scene_1_2_complete = True
            return news
        if choice == "2":
            news = self.news_2
            return news

    def end_by_news(self):
        self.news_displaying.append(self.get_news(self.detect_choice()))
        self.displaying = True
        self.counter = 0
        self.first_choice = 0
        self.second_choice = 0
        self.third_choice = 0
        self.generated = False
        self.delete = True

    def dialogue_end(self):
        self.game.dialogueSpots.in_dialogue = False
        self.counter = 0
        self.first_choice = 0
        self.second_choice = 0
        self.third_choice = 0
        self.generated = False
        self.delete = True

    def next_dialogue(self, choice):
        self.dialogueSpot[0].next_dialogue(choice)
        self.dialogueBoxes_list.clear()
        self.generate_four_choice()

    def draw(self, screen):
        for dialogueBox in self.dialogueBoxes_list:
            screen.blit(dialogueBox.image, dialogueBox.rect)
        for news in self.news_displaying:
            screen.blit(news, (340, 160))

    def update(self):

        if not self.game.dialogueSpots.in_dialogue:
            self.counter = 0

        if self.generate and not self.generated:
            self.generate_four_choice()
            self.game.arrows.generate_arrows()
            self.generate = False
            self.generated = True

        if self.delete:
            self.dialogueBoxes_list.clear()
            self.game.arrows.arrows_list.clear()
            self.delete = False


class DialogueSpot:
    def __init__(self, game, x, y):

        self.game = game

        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = TILE_SIZE
        self.height = TILE_SIZE

        self.image = pygame.Surface((self.width, self.height))
        self.image.set_colorkey((0, 0, 0))
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        self.counter = 0

        self.title = None
        self.first_choice = None
        self.second_choice = None
        self.third_choice = None
        self.fourth_choice = None

        self.first_choice_end = None
        self.second_choice_end = None
        self.third_choice_end = None
        self.fourth_choice_end = None

        self.first_choice_1_end = None
        self.second_choice_1_end = None
        self.third_choice_1_end = None
        self.fourth_choice_1_end = None

        self.first_choice_1_1_end = None
        self.second_choice_1_2_end = None
        self.third_choice_1_3_end = None
        self.fourth_choice_1_4_end = None

        self.first_choice_2_end = None
        self.second_choice_2_end = None
        self.third_choice_2_end = None
        self.fourth_choice_2_end = None

        self.first_choice_2_1_end = None
        self.second_choice_2_2_end = None
        self.third_choice_2_3_end = None
        self.fourth_choice_2_4_end = None

        self.first_choice_3_end = None
        self.second_choice_3_end = None
        self.third_choice_3_end = None
        self.fourth_choice_3_end = None

        self.first_choice_3_1_end = None
        self.second_choice_3_2_end = None
        self.third_choice_3_3_end = None
        self.fourth_choice_3_4_end = None

        self.first_choice_4_end = None
        self.second_choice_4_end = None
        self.third_choice_4_end = None
        self.fourth_choice_4_end = None

        self.first_choice_4_1_end = None
        self.second_choice_4_2_end = None
        self.third_choice_4_3_end = None
        self.fourth_choice_4_4_end = None

        self.title_1 = None
        self.first_choice_1 = None
        self.second_choice_1 = None
        self.third_choice_1 = None
        self.fourth_choice_1 = None

        self.title_1_1 = None
        self.first_choice_1_1 = None
        self.second_choice_1_1 = None
        self.third_choice_1_1 = None
        self.fourth_choice_1_1 = None

        self.title_1_2 = None
        self.first_choice_1_2 = None
        self.second_choice_1_2 = None
        self.third_choice_1_2 = None
        self.fourth_choice_1_2 = None

        self.title_1_3 = None
        self.first_choice_1_3 = None
        self.second_choice_1_3 = None
        self.third_choice_1_3 = None
        self.fourth_choice_1_3 = None

        self.title_1_4 = None
        self.first_choice_1_4 = None
        self.second_choice_1_4 = None
        self.third_choice_1_4 = None
        self.fourth_choice_1_4 = None

        self.title_2 = None
        self.first_choice_2 = None
        self.second_choice_2 = None
        self.third_choice_2 = None
        self.fourth_choice_2 = None

        self.title_2_1 = None
        self.first_choice_2_1 = None
        self.second_choice_2_1 = None
        self.third_choice_2_1 = None
        self.fourth_choice_2_1 = None

        self.title_2_2 = None
        self.first_choice_2_2 = None
        self.second_choice_2_2 = None
        self.third_choice_2_2 = None
        self.fourth_choice_2_2 = None

        self.title_2_3 = None
        self.first_choice_2_3 = None
        self.second_choice_2_3 = None
        self.third_choice_2_3 = None
        self.fourth_choice_2_3 = None

        self.title_2_4 = None
        self.first_choice_2_4 = None
        self.second_choice_2_4 = None
        self.third_choice_2_4 = None
        self.fourth_choice_2_4 = None

        self.title_3 = None
        self.first_choice_3 = None
        self.second_choice_3 = None
        self.third_choice_3 = None
        self.fourth_choice_3 = None

        self.title_3_1 = None
        self.first_choice_3_1 = None
        self.second_choice_3_1 = None
        self.third_choice_3_1 = None
        self.fourth_choice_3_1 = None

        self.title_3_2 = None
        self.first_choice_3_2 = None
        self.second_choice_3_2 = None
        self.third_choice_3_2 = None
        self.fourth_choice_3_2 = None

        self.title_3_3 = None
        self.first_choice_3_3 = None
        self.second_choice_3_3 = None
        self.third_choice_3_3 = None
        self.fourth_choice_3_3 = None

        self.title_3_4 = None
        self.first_choice_3_4 = None
        self.second_choice_3_4 = None
        self.third_choice_3_4 = None
        self.fourth_choice_3_4 = None

        self.title_4 = None
        self.first_choice_4 = None
        self.second_choice_4 = None
        self.third_choice_4 = None
        self.fourth_choice_4 = None

        self.title_4_1 = None
        self.first_choice_4_1 = None
        self.second_choice_4_1 = None
        self.third_choice_4_1 = None
        self.fourth_choice_4_1 = None

        self.title_4_2 = None
        self.first_choice_4_2 = None
        self.second_choice_4_2 = None
        self.third_choice_4_2 = None
        self.fourth_choice_4_2 = None

        self.title_4_3 = None
        self.first_choice_4_3 = None
        self.second_choice_4_3 = None
        self.third_choice_4_3 = None
        self.fourth_choice_4_3 = None

        self.title_4_4 = None
        self.first_choice_4_4 = None
        self.second_choice_4_4 = None
        self.third_choice_4_4 = None
        self.fourth_choice_4_4 = None

    def next_dialogue(self, choice):
        if choice == "1":
            self.player_choose_one()
            self.counter += 1
        if choice == "2":
            self.player_choose_two()
            self.counter += 1
        if choice == "3":
            self.player_choose_three()
            self.counter += 1
        if choice == "4":
            self.player_choose_four()
            self.counter += 1

    def player_choose_one(self):
        if self.counter == 0:
            self.title = self.title_1
            self.first_choice = self.first_choice_1
            self.second_choice = self.second_choice_1
            self.third_choice = self.third_choice_1
            self.fourth_choice = self.fourth_choice_1
        if self.counter == 1:
            if self.game.dialogueBoxes.first_choice == 1:
                self.title = self.title_1_1
                self.first_choice = self.first_choice_1_1
                self.second_choice = self.second_choice_1_1
                self.third_choice = self.third_choice_1_1
                self.fourth_choice = self.fourth_choice_1_1
            if self.game.dialogueBoxes.first_choice == 2:
                self.title = self.title_2_1
                self.first_choice = self.first_choice_2_1
                self.second_choice = self.second_choice_2_1
                self.third_choice = self.third_choice_2_1
                self.fourth_choice = self.fourth_choice_2_1
            if self.game.dialogueBoxes.first_choice == 3:
                self.title = self.title_3_1
                self.first_choice = self.first_choice_3_1
                self.second_choice = self.second_choice_3_1
                self.third_choice = self.third_choice_3_1
                self.fourth_choice = self.fourth_choice_3_1
            if self.game.dialogueBoxes.first_choice == 4:
                self.title = self.title_4_1
                self.first_choice = self.first_choice_4_1
                self.second_choice = self.second_choice_4_1
                self.third_choice = self.third_choice_4_1
                self.fourth_choice = self.fourth_choice_4_1
        self.game.dialogueBoxes.counter += 1

    def player_choose_two(self):
        if self.counter == 0:
            self.title = self.title_2
            self.first_choice = self.first_choice_2
            self.second_choice = self.second_choice_2
            self.third_choice = self.third_choice_2
            self.fourth_choice = self.fourth_choice_2
        if self.counter == 1:
            if self.game.dialogueBoxes.first_choice == 1:
                self.title = self.title_1_2
                self.first_choice = self.first_choice_1_2
                self.second_choice = self.second_choice_1_2
                self.third_choice = self.third_choice_1_2
                self.fourth_choice = self.fourth_choice_1_2
            if self.game.dialogueBoxes.first_choice == 2:
                self.title = self.title_2_2
                self.first_choice = self.first_choice_2_2
                self.second_choice = self.second_choice_2_2
                self.third_choice = self.third_choice_2_2
                self.fourth_choice = self.fourth_choice_2_2
            if self.game.dialogueBoxes.first_choice == 3:
                self.title = self.title_3_2
                self.first_choice = self.first_choice_3_2
                self.second_choice = self.second_choice_3_2
                self.third_choice = self.third_choice_3_2
                self.fourth_choice = self.fourth_choice_3_2
            if self.game.dialogueBoxes.first_choice == 4:
                self.title = self.title_4_2
                self.first_choice = self.first_choice_4_2
                self.second_choice = self.second_choice_4_2
                self.third_choice = self.third_choice_4_2
                self.fourth_choice = self.fourth_choice_4_2
        self.game.dialogueBoxes.counter += 1

    def player_choose_three(self):
        if self.counter == 0:
            self.title = self.title_3
            self.first_choice = self.first_choice_3
            self.second_choice = self.second_choice_3
            self.third_choice = self.third_choice_3
            self.fourth_choice = self.fourth_choice_3
        if self.counter == 1:
            if self.game.dialogueBoxes.first_choice == 1:
                self.title = self.title_1_3
                self.first_choice = self.first_choice_1_3
                self.second_choice = self.second_choice_1_3
                self.third_choice = self.third_choice_1_3
                self.fourth_choice = self.fourth_choice_1_3
            if self.game.dialogueBoxes.first_choice == 2:
                self.title = self.title_2_3
                self.first_choice = self.first_choice_2_3
                self.second_choice = self.second_choice_2_3
                self.third_choice = self.third_choice_2_3
                self.fourth_choice = self.fourth_choice_2_3
            if self.game.dialogueBoxes.first_choice == 3:
                self.title = self.title_3_3
                self.first_choice = self.first_choice_3_3
                self.second_choice = self.second_choice_3_3
                self.third_choice = self.third_choice_3_3
                self.fourth_choice = self.fourth_choice_3_3
            if self.game.dialogueBoxes.first_choice == 4:
                self.title = self.title_4_3
                self.first_choice = self.first_choice_4_3
                self.second_choice = self.second_choice_4_3
                self.third_choice = self.third_choice_4_3
                self.fourth_choice = self.fourth_choice_4_3
        self.game.dialogueBoxes.counter += 1

    def player_choose_four(self):
        if self.counter == 0:
            self.title = self.title_4
            self.first_choice = self.first_choice_4
            self.second_choice = self.second_choice_4
            self.third_choice = self.third_choice_4
            self.fourth_choice = self.fourth_choice_4
        if self.counter == 1:
            if self.game.dialogueBoxes.first_choice == 1:
                self.title = self.title_1_4
                self.first_choice = self.first_choice_1_4
                self.second_choice = self.second_choice_1_4
                self.third_choice = self.third_choice_1_4
                self.fourth_choice = self.fourth_choice_1_4
            if self.game.dialogueBoxes.first_choice == 2:
                self.title = self.title_2_4
                self.first_choice = self.first_choice_2_4
                self.second_choice = self.second_choice_2_4
                self.third_choice = self.third_choice_2_4
                self.fourth_choice = self.fourth_choice_2_4
            if self.game.dialogueBoxes.first_choice == 3:
                self.title = self.title_3_4
                self.first_choice = self.first_choice_3_4
                self.second_choice = self.second_choice_3_4
                self.third_choice = self.third_choice_3_4
                self.fourth_choice = self.fourth_choice_3_4
            if self.game.dialogueBoxes.first_choice == 4:
                self.title = self.title_4_4
                self.first_choice = self.first_choice_4_4
                self.second_choice = self.second_choice_4_4
                self.third_choice = self.third_choice_4_4
                self.fourth_choice = self.fourth_choice_4_4
        self.game.dialogueBoxes.counter += 1

    def display(self):
        pass

    def display_news(self):
        pass

    @classmethod
    def computer(cls, game, x, y):
        computer = cls(game, x, y)
        computer.width = TILE_SIZE
        computer.height = TILE_SIZE

        computer.title = COMPUTER_title
        computer.first_choice = COMPUTER_first_choice
        computer.second_choice = COMPUTER_second_choice
        computer.third_choice = COMPUTER_third_choice
        computer.fourth_choice = COMPUTER_fourth_choice

        computer.title_1 = COMPUTER_title_1
        computer.first_choice_1 = COMPUTER_first_choice_1
        computer.second_choice_1 = COMPUTER_second_choice_1
        computer.third_choice_1 = COMPUTER_third_choice_1
        computer.fourth_choice_1 = COMPUTER_fourth_choice_1

        computer.title_2 = COMPUTER_title_2
        computer.first_choice_2 = COMPUTER_first_choice_2
        computer.second_choice_2 = COMPUTER_second_choice_2
        computer.third_choice_2 = COMPUTER_third_choice_2
        computer.fourth_choice_2 = COMPUTER_fourth_choice_2

        computer.title_3 = COMPUTER_title_3
        computer.first_choice_3 = COMPUTER_first_choice_3
        computer.second_choice_3 = COMPUTER_second_choice_3
        computer.third_choice_3 = COMPUTER_third_choice_3
        computer.fourth_choice_3 = COMPUTER_fourth_choice_3

        computer.title_3_1 = COMPUTER_title_3_1
        computer.first_choice_3_1 = COMPUTER_first_choice_3_1
        computer.second_choice_3_1 = COMPUTER_second_choice_3_1
        computer.third_choice_3_1 = COMPUTER_third_choice_3_1
        computer.fourth_choice_3_1 = COMPUTER_fourth_choice_3_1

        computer.title_3_2 = COMPUTER_title_3_2
        computer.first_choice_3_2 = COMPUTER_first_choice_3_2
        computer.second_choice_3_2 = COMPUTER_second_choice_3_2
        computer.third_choice_3_2 = COMPUTER_third_choice_3_2
        computer.fourth_choice_3_2 = COMPUTER_fourth_choice_3_2

        computer.title_4 = COMPUTER_title_4
        computer.first_choice_4 = COMPUTER_first_choice_4
        computer.second_choice_4 = COMPUTER_second_choice_4
        computer.third_choice_4 = COMPUTER_third_choice_4
        computer.fourth_choice_4 = COMPUTER_fourth_choice_4

        computer.first_choice_end = False
        computer.second_choice_end = False
        computer.third_choice_end = False
        computer.fourth_choice_end = False

        computer.first_choice_1_end = True
        computer.second_choice_1_end = True
        computer.third_choice_1_end = True
        computer.fourth_choice_1_end = True

        computer.first_choice_2_end = True
        computer.second_choice_2_end = True
        computer.third_choice_2_end = True
        computer.fourth_choice_2_end = True

        computer.first_choice_3_end = False
        computer.second_choice_3_end = False
        computer.third_choice_3_end = True
        computer.fourth_choice_3_end = True

        computer.first_choice_3_1_end = True
        computer.second_choice_3_1_end = True
        computer.third_choice_3_1_end = True
        computer.fourth_choice_3_1_end = True

        computer.first_choice_3_2_end = True
        computer.second_choice_3_2_end = True
        computer.third_choice_3_2_end = True
        computer.fourth_choice_3_2_end = True

        computer.first_choice_4_end = True
        computer.second_choice_4_end = True
        computer.third_choice_4_end = True
        computer.fourth_choice_4_end = True

        computer.image = pygame.Surface((computer.width, computer.height))
        computer.image.set_colorkey((0, 0, 0))

        return computer

    @classmethod
    def Mom(cls, game, x, y):
        mom = cls(game, x, y)
        mom.width = TILE_SIZE
        mom.height = TILE_SIZE

        mom.title = MOM_title
        mom.first_choice = MOM_first_choice
        mom.second_choice = MOM_second_choice
        mom.third_choice = MOM_third_choice
        mom.fourth_choice = MOM_fourth_choice

        mom.title_1 = MOM_title_1
        mom.first_choice_1 = MOM_first_choice_1
        mom.second_choice_1 = MOM_second_choice_1
        mom.third_choice_1 = MOM_third_choice_1
        mom.fourth_choice_1 = MOM_fourth_choice_1

        mom.title_2 = MOM_title_2
        mom.first_choice_2 = MOM_first_choice_2
        mom.second_choice_2 = MOM_second_choice_2
        mom.third_choice_2 = MOM_third_choice_2
        mom.fourth_choice_2 = MOM_fourth_choice_2

        mom.first_choice_end = False
        mom.second_choice_end = False
        mom.third_choice_end = True
        mom.fourth_choice_end = True

        mom.first_choice_1_end = True
        mom.second_choice_1_end = True
        mom.third_choice_1_end = True
        mom.fourth_choice_1_end = True

        mom.first_choice_2_end = True
        mom.second_choice_2_end = True
        mom.third_choice_2_end = True
        mom.fourth_choice_2_end = True

        mom.image = pygame.Surface((mom.width, mom.height))
        mom.image.set_colorkey((0, 0, 0))

        return mom

    @classmethod
    def Mom2(cls, game, x, y):
        mom2 = cls(game, x, y)
        mom2.width = TILE_SIZE
        mom2.height = TILE_SIZE

        mom2.title = MOM_title
        mom2.first_choice = MOM_first_choice
        mom2.second_choice = MOM_second_choice
        mom2.third_choice = MOM2_third_choice
        mom2.fourth_choice = MOM_fourth_choice

        mom2.title_1 = MOM_title_1
        mom2.first_choice_1 = MOM_first_choice_1
        mom2.second_choice_1 = MOM_second_choice_1
        mom2.third_choice_1 = MOM_third_choice_1
        mom2.fourth_choice_1 = MOM_fourth_choice_1

        mom2.title_2 = MOM_title_2
        mom2.first_choice_2 = MOM_first_choice_2
        mom2.second_choice_2 = MOM_second_choice_2
        mom2.third_choice_2 = MOM_third_choice_2
        mom2.fourth_choice_2 = MOM_fourth_choice_2

        mom2.title_3 = MOM2_title_3
        mom2.first_choice_3 = MOM2_first_choice_3
        mom2.second_choice_3 = MOM2_second_choice_3
        mom2.third_choice_3 = MOM2_third_choice_3
        mom2.fourth_choice_3 = MOM2_fourth_choice_3

        mom2.first_choice_end = False
        mom2.second_choice_end = False
        mom2.third_choice_end = False
        mom2.fourth_choice_end = True

        mom2.first_choice_1_end = True
        mom2.second_choice_1_end = True
        mom2.third_choice_1_end = True
        mom2.fourth_choice_1_end = True

        mom2.first_choice_2_end = True
        mom2.second_choice_2_end = True
        mom2.third_choice_2_end = True
        mom2.fourth_choice_2_end = True

        mom2.first_choice_3_end = True
        mom2.second_choice_3_end = True
        mom2.third_choice_3_end = True
        mom2.fourth_choice_3_end = True

        mom2.image = pygame.Surface((mom2.width, mom2.height))
        mom2.image.set_colorkey((0, 0, 0))

        return mom2

    @classmethod
    def Clue_paper(cls, game, x, y):
        clue_paper = cls(game, x, y)
        clue_paper.width = TILE_SIZE
        clue_paper.height = TILE_SIZE
        clue_paper.name = 'clue paper'

        clue_paper.title = CLUE_PAPER
        clue_paper.first_choice = TAKE
        clue_paper.second_choice = LEAVE
        clue_paper.third_choice = LEAVE
        clue_paper.fourth_choice = LEAVE

        clue_paper.first_choice_end = True
        clue_paper.second_choice_end = True
        clue_paper.third_choice_end = True
        clue_paper.fourth_choice_end = True

        clue_paper.image = pygame.Surface((clue_paper.width, clue_paper.height))
        clue_paper.image.set_colorkey((0, 0, 0))

        return clue_paper


class DialogueSpotGroup:
    def __init__(self, game):
        self.game = game
        self.dialogueSpots_list = []
        self.in_dialogue = False
        self.player_at_dialogueSpot = False
        self.in_used = []

    def refresh_dialogueSpots(self):
        self.dialogueSpots_list.clear()
        self.in_used.clear()
        for i, row in enumerate(self.game.map_in_use):
            for j, column in enumerate(row):
                if column == "c":
                    self.generate_dialogueSpot('computer', j, i)
                if self.game.scene_1_1_complete:
                    if not self.game.scene_1_3_complete:
                        if self.game.scene_1_2_complete:
                            if column == "m":
                                self.generate_dialogueSpot('Mom2', j, i)
                        else:
                            if column == "m":
                                self.generate_dialogueSpot('Mom', j, i)
                if column == "i":
                    for item in self.game.items.items_list:
                        if item.name == 'clue paper':
                            self.generate_dialogueSpot('clue paper', j, i)

    def generate_dialogueSpot(self, name, x, y):
        new_spot = None
        if name is None:
            return
        if name == 'computer':
            new_spot = DialogueSpot.computer(self.game, x, y)
        if name == 'Mom':
            new_spot = DialogueSpot.Mom(self.game, x, y)
        if name == 'Mom2':
            new_spot = DialogueSpot.Mom2(self.game, x, y)
        if name == 'clue paper':
            new_spot = DialogueSpot.Clue_paper(self.game, x, y)

        self.dialogueSpots_list.append(new_spot)

    def get_in_used_dialogueSpot(self):
        for player in self.game.players.players_list:
            for dialogueSpot in self.dialogueSpots_list:
                hit = dialogueSpot.rect.colliderect(player.rect)
                if hit:
                    self.player_at_dialogueSpot = True
                    self.in_used.append(dialogueSpot)

    def update(self):
        self.player_at_dialogueSpot = False
        self.get_in_used_dialogueSpot()
        if not self.player_at_dialogueSpot:
            self.in_used.clear()

    def draw(self, screen):
        for dialogueSpot in self.dialogueSpots_list:
            screen.blit(dialogueSpot.image, dialogueSpot.rect)


class Door:
    def __init__(self, game, x, y):
        self.game = game

        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = TILE_SIZE
        self.height = TILE_SIZE

        self.tilemap1 = None
        self.tilemap2 = None

        self.image = pygame.Surface((self.width, self.height))
        self.image.fill((0, 0, 0))

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    @classmethod
    def home(cls, game, x, y):
        home = cls(game, x, y)
        home.width = TILE_SIZE
        home.height = TILE_SIZE
        home.image = pygame.Surface((home.width, home.height))
        home.image.fill((0, 0, 0))
        home.tilemap_self = tilemap_4
        home.tilemap_street = tilemap_2
        return home

    @classmethod
    def school(cls, game, x, y):
        school = cls(game, x, y)
        school.width = TILE_SIZE
        school.height = TILE_SIZE
        school.image = pygame.Surface((school.width, school.height))
        school.image.fill((0, 0, 0))
        school.tilemap_self = tilemap_3
        school.tilemap_street = tilemap_5
        return school


class DoorGroup:
    def __init__(self, game):
        self.doors_list = []
        self.game = game
        self.player_at_door = False
        self.next_map = None
        self.in_street = False


    def generate_door(self, name, x, y):
        new_door = None
        if name is None:
            return
        if name == 'home':
            new_door = Door.home(self.game, x, y)
        if name == 'school':
            new_door = Door.school(self.game, x, y)
        self.doors_list.append(new_door)

    def detect_player(self):
        for player in self.game.players.players_list:
            for door in self.doors_list:
                hit = door.rect.colliderect(player.rect)
                if hit:
                    self.player_at_door = True
                    if self.in_street == True:
                        self.next_map = door.tilemap_self
                    elif self.in_street == False:
                        self.next_map = door.tilemap_street

    def map_change(self):
        if self.player_at_door:
            self.game.door_sound.play()
            self.game.players.players_list.clear()
            self.game.NPCs.NPCs_list.clear()
            self.game.grounds.grounds_list.clear()
            self.game.blocks.blocks_list.clear()
            self.game.dialogueSpots.dialogueSpots_list.clear()
            self.game.doors.doors_list.clear()
            self.game.items.items_list.clear()
            self.game.map_in_use = self.next_map
            self.game.create_tilemap()
            self.in_street = not self.in_street


    def update(self):
        self.detect_player()
        self.map_change()
        self.player_at_door = False

    def draw(self, screen):
        for door in self.doors_list:
            screen.blit(door.image, door.rect)


class Item:
    def __init__(self, game, x ,y):
        self.game = game
        self.name = None
        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = TILE_SIZE
        self.height = TILE_SIZE

        self.image = pygame.Surface((self.width, self.height))
        self.image.set_colorkey((0, 0, 0))

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    @classmethod
    def Clue_paper(cls, game, x, y):
        clue_paper = cls(game, x, y)
        clue_paper.x = TILE_SIZE
        clue_paper.y = TILE_SIZE
        clue_paper.width = TILE_SIZE
        clue_paper.height = TILE_SIZE
        clue_paper.name = 'clue paper'

        clue_paper.image = clue_paper.game.clue_paper.get_sprite(0, 0, clue_paper.width, clue_paper.height)
        return clue_paper


class ItemGroup:
    def __init__(self, game):
        self.items_list = []
        self.game = game

    def generate_item(self, name, x, y):
        new_item = None
        if name is None:
            return
        if name == 'clue paper':
            new_item = Item.Clue_paper(self.game, x, y)
        self.items_list.append(new_item)

    def draw(self, screen):
        for item in self.items_list:
            screen.blit(item.image, item.rect)

    def detect_pick_up_item(self):
        dialogueSpot = self.game.dialogueSpots.in_used
        for arrow in self.game.arrows.arrows_list:
            if arrow.rect.y == ARROW_CHOOSE_ONE_Y:
                for item in self.items_list:
                    if dialogueSpot[0].name == item.name:
                        self.game.players.items_list.append(item)
                        self.items_list.pop(self.items_list.index(item))
                        if item.name == 'clue paper':
                            pygame.mixer.music.load(self.game.chase_music)
                            pygame.mixer.music.set_volume(0.3)
                            pygame.mixer.music.play(-1)

